from operator import mod
from django.contrib import admin
from . import models
# Register your models here.
admin.site.register(models.contact)